# UNIX Fundamentals Guessing Game

## Introduction

Welcome to the UNIX Fundamentals Guessing Game! This interactive command-line game is designed to test and improve your knowledge of UNIX basics. With a focus on fundamental concepts, commands, and principles of UNIX, this game is perfect for beginners and those looking to refresh their knowledge.

## Installation

To install the game, follow these steps:

1. **Clone the Repository**  
   Clone this repository to your local machine using:
   ```
   git clone https://github.com/grioool/guessing-game.git
   ```

2. **Navigate to the Game Directory**  
   Change into the game directory:
   ```
   cd guessing-game
   ```

## Usage

To start playing the game, follow these instructions:

1. **Run the Game**  
   Run the game using Python:
   ```
   python game.py
   ```

2. **Playing the Game**  
   - The game will present you with questions about UNIX fundamentals.
   - Type in your answer and press Enter.
   - The game will provide immediate feedback on whether your answer was correct.
   - Continue answering questions until the end of the game.
   - Your final score will be displayed at the end.

## Game Features

- **Wide Range of Questions:** Covers various aspects of UNIX, including basic commands, file systems, processes, and more.
- **Immediate Feedback:** Learn as you play with instant responses to your answers.
- **Score Tracking:** Keep track of your progress with a scoring system.

Enjoy the game and happy learning!